I have added the leaderboard in, it doesn't work but 
you might want to look what I was on to about changing the sizing of table
to match the name sizes. You don't have to and don't mark it just thought
it might be intresting *wink face*
