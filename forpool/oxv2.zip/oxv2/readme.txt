- made improvements from last submit
- have now added the leaderboard

before running the program make sure you have the leaderboard and temp leaderboard file in the same dir. 
